public class Ex2 {
    public static void main(String[] args) throws Exception {
        int x=0;
        int y=0;
while (y<3){
while (x<2){
    System.out.println("Alfa");
    x++;
}
System.out.println("Beta");
y++;
x=0;
}
System.out.println("Zeta");
    }
}
