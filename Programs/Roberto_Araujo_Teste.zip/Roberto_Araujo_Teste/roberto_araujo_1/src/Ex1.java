public class Ex1 {
    public static void main(String[] args) throws Exception {
        int x=0;
        int y=0;
        for (x=0; 2 > y; y++ ) {
        for (x=0; 3 > x; x++ ) {
            System.out.println("Alfa");
        }
        System.out.println("Beta");
        x=0;
    }
    System.out.println("Zeta");
}
}
